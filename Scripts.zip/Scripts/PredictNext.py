import math
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import CSVReader

# Input array
def generate_input(range):
    open = CSVReader.returnWickData('USDCAD_2023-2024.csv')['Open'].values      # File to grab data form csv format
    #close = CSVReader.returnWickData('EURUSD_202-2024.csv')['Close'].values
        
    if range == 'open': return np.array(open)
    else: return np.array(close)

# Function to train the model
def train_model(X_train, y_train):
    model = LinearRegression()
    model.fit(X_train, y_train)
    return model

# Function to predict the next number
def predict_next_number(model, X_test):
    return model.predict(X_test)

# Function to evaluate the model accuracy
def evaluate_model(model, X_test, y_test):
    predictions = model.predict(X_test)
    accuracy = model.score(X_test, y_test)
    return accuracy, predictions

# Split sequence into features (X) and target (y)
openData = generate_input('open')

X_train = openData[:-1].reshape(-1, 1)
y_train = openData[1:]

# Train the model
model = train_model(X_train, y_train)

# Predict the next number
next_number = predict_next_number(model, [[openData[-1]]])[0]

# Evaluate the model accuracy
accuracy, predictions = evaluate_model(model, X_train, y_train)


print("Original Sequence:", openData)
print("Predictions:", predictions)
print("Next number prediction:", next_number)
print("Model accuracy:", accuracy)

# Plot the model
plt.plot(openData, label = "Input")
plt.plot(predictions, label = "Predictions")
plt.xlabel("Count")
plt.ylabel("Value")
plt.grid(True)
plt.show()